These csv files contain the raw data we calculated, and you can run "contour.py" and "zigzag.py" to get the image quickly.

"a11.py" and "a12.py" are our source code.